module.exports ={
    DB_NAME : "ecom_db",
    DB_URL : "mongodb://localhost/ecom_db"   //for windows 0.0.0.0
}