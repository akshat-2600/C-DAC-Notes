/**
 * This file will contain the server configurations
 */

module.exports = {
    PORT : 8080
}